﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Controls;

namespace ToursApp
{
    class Manager
    {
        public static Frame MainFrame { get; set; }
    }
}
